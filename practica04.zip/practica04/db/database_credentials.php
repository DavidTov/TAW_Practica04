<?php
	define('DB_HOST', 'localhost');
	define('DB_DATABASE', 'practica_04');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
?>